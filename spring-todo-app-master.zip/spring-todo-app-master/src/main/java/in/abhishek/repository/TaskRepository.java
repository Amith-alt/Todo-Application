package in.abhishek.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.abhishek.entity.TaskEntity;

public interface TaskRepository extends JpaRepository<TaskEntity, Long> {

}
