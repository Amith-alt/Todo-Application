package in.abhishek.serviceimlementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.abhishek.entity.TaskEntity;
import in.abhishek.repository.TaskRepository;
import in.abhishek.service.TaskServices;

@Service
public class TaskServicesImplementation implements TaskServices{
	@Autowired
	private TaskRepository taskrepository;
	@Override
	public List<TaskEntity> getAllTasks() {
		return taskrepository.findAll();
		
	}

	@Override
	public void createTask(String title) {
		TaskEntity task = new TaskEntity();
		task.setTitle(title);
		task.setCompleted(false);
		taskrepository.save(task);
	}

	@Override
	public void deleteTask(Long id) {
		taskrepository.deleteById(id);
	}

	@Override
	public void toggleTask(Long id) {
		TaskEntity task = taskrepository.findById(id)
				.orElseThrow(()->new IllegalArgumentException("Invalid Task id"));
		task.setCompleted(!task.isCompleted());
		taskrepository.save(task);
	}

}
