package in.abhishek.service;

import java.util.List;

import in.abhishek.entity.TaskEntity;

public interface TaskServices {
	List<TaskEntity> getAllTasks();
	void createTask(String title);
	void deleteTask(Long id);
	void toggleTask(Long id);

}
