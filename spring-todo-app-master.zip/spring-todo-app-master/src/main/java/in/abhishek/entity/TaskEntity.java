package in.abhishek.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class TaskEntity {
	@Id	//Represents Primary Key
	@GeneratedValue(strategy = GenerationType.AUTO) //Helps to auto increment the value
	private Long id;
	private String title;
	private boolean completed;
}
